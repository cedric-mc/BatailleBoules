#!/usr/bin/env python
# Programmeurs : Cédric Mariya Constantine et Wilson Groevius
# ------------------------------ Importation depuis le dossier source
from upemtk import *
from default import largeur_Fenetre, hauteur_Fenetre
from game import GAME


def INTERFACE():
    """Corps principal du jeu avec création et destruction de l'interface"""
    dico_j1, dico_j2 = dict(), dict() # Forme du dictionnaire : clé : identifiant du cercle ; valeur : [x, y, r].
    dico_obs = dict()
    rayon = 50
    compteur = 1
    cree_fenetre(largeur_Fenetre, hauteur_Fenetre)
    GAME(dico_j1, dico_j2, dico_obs, rayon, compteur)
    ferme_fenetre()

if __name__ == '__main__':
    INTERFACE()
